var searchData=
[
  ['aucblue',['aucBlue',['../main_8c.html#a68c281219659f3ddbe92c8d67cafad50',1,'main.c']]],
  ['aucgreen',['aucGreen',['../main_8c.html#ae915e71430e8066fa0d668a7afdff0ab',1,'main.c']]],
  ['aucred',['aucRed',['../main_8c.html#a66c25342f6d0ec5eae0880aeff209383',1,'main.c']]]
];
