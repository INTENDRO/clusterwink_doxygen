var searchData=
[
  ['ad8bit_5finit',['AD8bit_Init',['../utils_8c.html#a7433311b057ef5b41de10f9343f714f0',1,'AD8bit_Init(void):&#160;utils.c'],['../utils_8h.html#a7433311b057ef5b41de10f9343f714f0',1,'AD8bit_Init(void):&#160;utils.c']]],
  ['ad8bit_5fmeasurement',['AD8bit_Measurement',['../utils_8c.html#a02b7c7e2979bbca9d33968829d4f7d27',1,'AD8bit_Measurement(void):&#160;utils.c'],['../utils_8h.html#a02b7c7e2979bbca9d33968829d4f7d27',1,'AD8bit_Measurement(void):&#160;utils.c']]]
];
