var searchData=
[
  ['ringbuffer',['RINGBUFFER',['../main_8c.html#a11ad2b0ff082b1b72f8425293c9644cc',1,'main.c']]]
];
