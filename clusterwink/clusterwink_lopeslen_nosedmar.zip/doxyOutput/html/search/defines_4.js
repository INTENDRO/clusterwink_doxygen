var searchData=
[
  ['ringbuff_5fcount_5ft',['RingBuff_Count_t',['../ringbuffer_8h.html#ac7138106260c3e40b496566bddacf8f1',1,'ringbuffer.h']]],
  ['ringbuff_5fdata_5ft',['RingBuff_Data_t',['../ringbuffer_8h.html#acf1a805a0c6814d6d188a8484895cda4',1,'ringbuffer.h']]]
];
