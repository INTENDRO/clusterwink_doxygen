var searchData=
[
  ['buffer',['Buffer',['../struct_ring_buff__t.html#a34a3157c29f784eaf00133705e14f341',1,'RingBuff_t']]]
];
