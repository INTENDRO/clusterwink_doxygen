var searchData=
[
  ['buffer',['Buffer',['../struct_ring_buff__t.html#a34a3157c29f784eaf00133705e14f341',1,'RingBuff_t']]],
  ['buffer_5fsize',['BUFFER_SIZE',['../ringbuffer_8h.html#a6b20d41d6252e9871430c242cb1a56e7',1,'ringbuffer.h']]]
];
