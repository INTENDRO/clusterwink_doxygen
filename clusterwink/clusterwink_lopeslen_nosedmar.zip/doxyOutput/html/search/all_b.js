var searchData=
[
  ['send',['SEND',['../rgbooster_8h.html#abc9603445bf79a3793831ee1d0ea8890',1,'rgbooster.h']]],
  ['sendbit',['SendBit',['../rgbooster_8c.html#aebfe625207d08e6617ebabb89d3521c7',1,'SendBit(unsigned char ucRed, unsigned char ucGreen, unsigned char ucBlue):&#160;rgbooster.c'],['../rgbooster_8h.html#aebfe625207d08e6617ebabb89d3521c7',1,'SendBit(unsigned char ucRed, unsigned char ucGreen, unsigned char ucBlue):&#160;rgbooster.c']]],
  ['sendstrip',['SendStrip',['../rgbooster_8c.html#a4a3253bf5a08bd8baa9b2d3040f9b96d',1,'SendStrip(unsigned char *ucRed_ptr, unsigned char *ucGreen_ptr, unsigned char *ucBlue_ptr, unsigned char ucLength):&#160;rgbooster.c'],['../rgbooster_8h.html#a4a3253bf5a08bd8baa9b2d3040f9b96d',1,'SendStrip(unsigned char *ucRed_ptr, unsigned char *ucGreen_ptr, unsigned char *ucBlue_ptr, unsigned char ucLength):&#160;rgbooster.c']]],
  ['sendstrip_5foff',['SendStrip_Off',['../rgbooster_8c.html#a9d07e9ea2b67f8e8455e77503a3ece3e',1,'SendStrip_Off(unsigned char ucLength):&#160;rgbooster.c'],['../rgbooster_8h.html#a9d07e9ea2b67f8e8455e77503a3ece3e',1,'SendStrip_Off(unsigned char ucLength):&#160;rgbooster.c']]],
  ['setduty',['setDuty',['../utils_8c.html#a550c27d1a5da34b56c38bdca0eff3855',1,'setDuty(unsigned char ucPercent):&#160;utils.c'],['../utils_8h.html#a550c27d1a5da34b56c38bdca0eff3855',1,'setDuty(unsigned char ucPercent):&#160;utils.c']]],
  ['spi_2ec',['spi.c',['../spi_8c.html',1,'']]],
  ['spi_2eh',['spi.h',['../spi_8h.html',1,'']]],
  ['spislave_5finit',['SPISlave_Init',['../spi_8c.html#a41e76811ae07d6f611bafbbfdf560693',1,'SPISlave_Init(void):&#160;spi.c'],['../spi_8h.html#a41e76811ae07d6f611bafbbfdf560693',1,'SPISlave_Init(void):&#160;spi.c']]],
  ['startpwm',['startPWM',['../utils_8c.html#a361f504f21334e83d854f8c3a37afc3e',1,'startPWM(void):&#160;utils.c'],['../utils_8h.html#a361f504f21334e83d854f8c3a37afc3e',1,'startPWM(void):&#160;utils.c']]],
  ['stoppwm',['stopPWM',['../utils_8c.html#a1c563c736213741b4eb9f2626d48d6af',1,'stopPWM(void):&#160;utils.c'],['../utils_8h.html#a1c563c736213741b4eb9f2626d48d6af',1,'stopPWM(void):&#160;utils.c']]]
];
