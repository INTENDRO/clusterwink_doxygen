var searchData=
[
  ['in',['In',['../struct_ring_buff__t.html#a041d05fdfa09d6161d8353441540ef1c',1,'RingBuff_t']]],
  ['initpwm',['initPWM',['../utils_8c.html#a134996da7a56819203c50b7da35a0027',1,'initPWM(unsigned char ucPercent):&#160;utils.c'],['../utils_8h.html#a134996da7a56819203c50b7da35a0027',1,'initPWM(unsigned char ucPercent):&#160;utils.c']]],
  ['initrgbooster',['initRGBooster',['../rgbooster_8c.html#acf099652a3bc254ab5a77c8df9e1eae0',1,'initRGBooster(void):&#160;rgbooster.c'],['../rgbooster_8h.html#acf099652a3bc254ab5a77c8df9e1eae0',1,'initRGBooster(void):&#160;rgbooster.c']]],
  ['int1_5finit',['INT1_Init',['../rgbooster_8c.html#a461a2a059af53d4fcdaafeaa453a4017',1,'INT1_Init(void):&#160;rgbooster.c'],['../rgbooster_8h.html#a461a2a059af53d4fcdaafeaa453a4017',1,'INT1_Init(void):&#160;rgbooster.c']]],
  ['isr',['ISR',['../main_8c.html#af9cad97352f5ba9bbd800446131125a6',1,'ISR(SPI_STC_vect):&#160;main.c'],['../main_8c.html#a22acfb428840c6d9aa212764589cf6c6',1,'ISR(INT1_vect):&#160;main.c']]]
];
